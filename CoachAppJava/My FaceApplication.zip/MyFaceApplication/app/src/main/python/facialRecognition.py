import cv2
import face_recognition
from os.path import dirname, join
import base64
from io import BytesIO
from PIL import Image
import tempfile




def main():
	return "hello helmi makwek"

def face(firstFaceName,secondFaceName):


	#fileimage1 = join(dirname(__file__), "img/"+firstFaceName+".jpg")
	#fileimage2 = join(dirname(__file__), "img/"+secondFaceName+".jpg")


# Convertir l'image codée en base64 en un format d'image
	imgdata = base64.b64decode(firstFaceName)
	image = Image.open(BytesIO(imgdata))

	with tempfile.NamedTemporaryFile(delete=False,suffix='.jpg') as f:
		image.save(f, 'JPEG')
		temp_file = f.name



	#load image
	myFirstPhoto= face_recognition.load_image_file(temp_file)

	# convert BGR format
	myFirstPhotoRGB=cv2.cvtColor(myFirstPhoto,cv2.COLOR_BGR2RGB)
	# Detect the face
	myFirstFace=face_recognition.face_locations(myFirstPhotoRGB)[0]
	encodFirstFace=face_recognition.face_encodings(myFirstPhotoRGB)[0]
	resultFirstFace=cv2.rectangle(myFirstPhotoRGB,(myFirstFace[3],myFirstFace[0]),(myFirstFace[1],myFirstFace[2]),(255,0,0),2)


	imgdata2 = base64.b64decode(secondFaceName)
	image2 = Image.open(BytesIO(imgdata2))

	with tempfile.NamedTemporaryFile(delete=False,suffix='.jpg') as f2:
		image2.save(f2, 'JPEG')
		temp_file2 = f2.name

	"""with tempfile.NamedTemporaryFile(delete=False,suffix='.jpg') as f:
		secondFaceName.save(f, 'JPEG')
	temp_file2 = f.name"""

	#mySecondPhoto= face_recognition.load_image_file(fileimage2)
	mySecondPhoto= face_recognition.load_image_file(temp_file2)
	mySecondPhotoRGB=cv2.cvtColor(mySecondPhoto,cv2.COLOR_BGR2RGB)
	mySecondFace=face_recognition.face_locations(mySecondPhotoRGB)[0]
	encodSecondFace=face_recognition.face_encodings(mySecondPhotoRGB)[0]
	resultSecondFace=cv2.rectangle(mySecondPhotoRGB,(mySecondFace[3],mySecondFace[0]),(mySecondFace[1],mySecondFace[2]),(255,0,0),2)

	recognition=face_recognition.compare_faces([encodFirstFace],encodSecondFace)
	recognitionvalue=face_recognition.face_distance([encodFirstFace],encodSecondFace)





	# print(recognition,recognitionvalue)







	return recognition,recognitionvalue





