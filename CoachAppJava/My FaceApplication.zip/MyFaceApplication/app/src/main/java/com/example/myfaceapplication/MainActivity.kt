package com.example.myfaceapplication

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.chaquo.python.Python
import org.eclipse.paho.android.service.MqttAndroidClient
import org.eclipse.paho.client.mqttv3.*
import java.io.ByteArrayOutputStream

import android.content.Context

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData

import org.eclipse.paho.client.mqttv3.*
import java.util.*


class MainActivity : AppCompatActivity() {



    private var topic: String? = null
    private var infouser: String? = null
    private  var clientID:String? = null
    private var client: MqttAndroidClient? = null
    private lateinit var myresult: TextView
    private lateinit var myresultreservation: TextView

    private val REQUEST_IMAGE_CAPTURE = 1
    private lateinit var mImageView: ImageView

    private val mqttClient by lazy {
        MQTTManager(this)
    }


    private fun init() {

        clientID = "xx11x"
        topic = "pdsface/images"


        /*client =
            MqttAndroidClient(this.getApplicationContext(), host, clientId)*/


        client = MqttAndroidClient(this.getApplicationContext(), "tcp://172.31.254.21:72",
            clientID)
        /*client = MqttAndroidClient(this.getApplicationContext(), "tcp://broker.hivemq.com:1883",
            clientID)*/

        mqttClient.connect()


        // connect()

    }








    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mImageView = findViewById(R.id.image_view)

        init()





    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            val imageBitmap = data?.extras?.get("data") as Bitmap
            mImageView.setImageBitmap(imageBitmap)




            val stream = ByteArrayOutputStream()
            imageBitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
            val byteArray = stream.toByteArray()
            val base64StringSelfie = Base64.encodeToString(byteArray, Base64.NO_WRAP)

            try {
                checkFacial(base64StringSelfie)
            }catch (e : java.lang.Exception){
                Log.v("testvisage","avance ton visage")
                myresult = findViewById(R.id.textView)
                myresult.setTextColor(Color.RED)
                myresult.text = "merci de bien placer votre visage"
            }
            // checkFacial(base64StringSelfie)


        }
    }

    fun takePicture(view: View) {
        Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
            takePictureIntent.resolveActivity(packageManager)?.also {
                startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE)
            }
        }
    }

    fun checkFacial(selfie: String){




        val preferences = getSharedPreferences("prefs_file", MODE_PRIVATE)
        val value = preferences.getString("userdistant", "")



        if (value != null) {
            Log.v("TTTEEESSSSSTTTTT3",value)
            Log.v("TTTEEESSSSSTTTTT3",selfie)

            val py = Python.getInstance();
            val pyob = py.getModule("facialRecognition");

            val obj = pyob.callAttr("face",value,selfie);

            Log.v("test facialRecognition",obj.toString())
            val variableType3 = obj::class.java


            if (obj.toString()[2].toString() =="T"){
                myresult = findViewById(R.id.textView)
                myresultreservation = findViewById(R.id.textView2)
                myresult.setTextColor(Color.GREEN)
                myresultreservation.setTextColor(Color.BLACK)
                var infouser = preferences.getString("infouser", "")

                var delimiteruser = "!"

                val inforeservation = infouser?.split(delimiteruser)



               // myresult.text = "AUTHENTIFACTION REUSSIE : VOUS ETES BIEN L'ORGANISATEUR : "+ (infouser?.get(0) ?: "") + (infouser?.get(0) ?: "") + " Information de la reservation : salle : "+(infouser?.get(1) ?: "") +" durée "+(infouser?.get(2) ?: "")
                myresult.text = "AUTHENTIFACTION REUSSIE : VOUS ETES BIEN L'ORGANISATEUR : "+ (inforeservation?.get(0) ?: "") + " " +(inforeservation?.get(1) ?: "")
                myresultreservation.text = " Information de la reservation : salle : "+(inforeservation?.get(2) ?: "") +" durée "+(inforeservation?.get(3) ?: "")
            }else{
                myresult = findViewById(R.id.textView)
                myresult.setTextColor(Color.RED)
                myresult.text = "AUTHENTIFACTION ECHOUE : VOUS N'ETES PAS L'ORGANISATEUR"
            }
        }else{
            myresult = findViewById(R.id.textView)
            myresult.setTextColor(Color.RED)
            myresult.text = "PAS ENCORE DE RESERAVTION DANS LES 10 MINS"
        }

        /* val firstFaceName="messi"
        val secondFaceName="messi2"
        val obj = pyob.callAttr("face",firstFaceName,secondFaceName);
        Log.v("test facialRecognition",obj.toString())*/

    }




    fun connect() {
        try {
            val token = client?.connect()
            token?.actionCallback = object : IMqttActionListener {
                override fun onSuccess(asyncActionToken: IMqttToken) {
                    // We are connected
                    Log.d("TTTEEESSSSSTTTTT", "onSuccess : le mobile est prét")
                    sub()
                }

                override fun onFailure(asyncActionToken: IMqttToken, exception: Throwable) {
                    // Something went wrong e.g. connection timeout or firewall problems
                    Log.d("TAG", "onFailure")
                }
            }
        } catch (e: MqttException) {
            e.printStackTrace()
        }
    }

    /*fun connect() {
        val mqttConnectOptions = MqttConnectOptions()

        //mqttConnectOptions.isAutomaticReconnect = false
        mqttConnectOptions.isCleanSession = true
        try {
            client?.connect(mqttConnectOptions, null, object : IMqttActionListener {
                override fun onSuccess(asyncActionToken: IMqttToken) {
                    Log.w("Mqtt", "sa7AYT")
                }

                override fun onFailure(asyncActionToken: IMqttToken, exception: Throwable) {
                    Log.w("Mqtt", "Failed to connect to: " + exception.toString())
                }
            })
        } catch (ex: MqttException) {
            ex.printStackTrace()
        }
    }*/


    private fun sub() {
        try {
            client?.subscribe(topic, 0)
            client?.setCallback(object : MqttCallback {
                override fun connectionLost(cause: Throwable) {
                    //log
                }

                @Throws(Exception::class)
                override fun messageArrived(topic: String, message: MqttMessage) {
                    Log.d("TAG", "topic :$topic")
                    val resultmessagec = String(message.payload)
                    Log.d("TTTEEESSSSSTTTTT2", "message :$resultmessagec")
                    val preferences = getSharedPreferences("prefs_file", MODE_PRIVATE)
                    val editor = preferences.edit()

                    var delimiter = "#!#!#"

                    val infos = resultmessagec.split(delimiter)
                    infouser=infos[1]
                    Log.d("teesssttttt0",infos[0])
                    editor.putString("userdistant", infos[1])
                    editor.putString("infouser", infos[0])
                    editor.apply()
                    // checkFacial()


                }

                override fun deliveryComplete(token: IMqttDeliveryToken) {
                    //toast
                }
            })
        } catch (e: MqttException) {
        }
    }












}

